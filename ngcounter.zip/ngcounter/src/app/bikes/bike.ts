

export class Bike {
    id: number;
    model: String;
    manufacturer: String;

}