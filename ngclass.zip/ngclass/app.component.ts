import { Component,  ViewChild ,ElementRef,OnInit, Inject,ChangeDetectorRef,OnChanges} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {ChartsModule, Color} from 'ng2-charts';
import{WindEnergyService} from '../app/services/windenergy.service';
import{EnergyService} from '../app/services/wind.service';
import{IEnergy} from './services/Energy';
import{config} from './config';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/interval';
import { LocalStorage, SharedStorage } from 'ngx-store';
// import {LocalStorage, SessionStorage} from "angular-localstorage";
// import 'chart.js/src/chart';
declare var $:any;
declare var options:any;
declare var Chart :any;
declare var myChart :any;








@Component({
  selector: 'app-root',
  templateUrl: './testrel.component.html',
  styleUrls: ['./testrel.css'],
  providers: [EnergyService,WindEnergyService]
})


export class AppComponent implements OnInit,OnChanges {

  titleClasses={
"red-text":false,"purple-text":true


  };
  

  Wrapper={
"wrap5":true,
"wrap6":false
  }


  @LocalStorage() protected userNote: string = '';

  // @LocalStorage() public username:string = '';


  @ViewChild('mycanvas')mycanvas:ElementRef; 


  public options:any;
  public errorMsg :string ="10" ;
  public errornumber:number=62;
  public numbers :number[] =[];
  public numberss :IEnergy[];
  

  public emissionTotal:number[]=[];

title=""; 
num =0;
energies:IEnergy[];
emissionfreePercentage=0;
emissionfreeTitle="";






constructor(private _energyService:EnergyService,private _windEnergyService: WindEnergyService,private ref: ChangeDetectorRef){

  
  // setTimeout(() => {
  //   console.log('userNote:', this.userNote); // it should be changed after user's visit to NestedComponent
  // }, 5000);

}

// getRefresh(){
//   setInterval(() => {
//     alert(new Date());
//   location.reload();
//   }, 5000);
//   }


ngOnChanges(){
  this.num =0;
}




menulist: boolean = false;




 ngOnInit(){
  //  this.getRefresh();
    console.log("ngInit hooked");
  
  //   $("button").click(function(){  
  //     $("#percentagewind").removeAttr('data-max', '5000').attr('data-max', '5000');
  // });
  //Chart.defaults.global.animation.duration = 13000;
// Working Fine

// Observable
// .interval(2*60*1000)
// .timeInterval().this._energyService.getEnergy(response).subscribe((response) => {
//   let x=100;
//   let y=100;
//   console.log(this.numberss = response);
//   this.num = response[0].EnergyValue;
//   this.title =response[0].EnergyName;
//   this.numbers[0] = response[0].EnergyValue;
//   this.numbers[1]= x-response[0].EnergyValue;
//   this.doughnutChartData= this.numbers;

//   this.emissionfreePercentage = response[1].EnergyValue;
//   this.emissionfreeTitle = response[1].EnergyName;
//   this.emissionTotal[0] = response[1].EnergyValue;
//   this.emissionTotal[1] = y- response[1].EnergyValue;
//   this.doughnutChartDataEmission3 = this.emissionTotal;
//   console.log(this.numbers[1])
//  // 
// //this.doughnutChartData3 = this.numbers[0][1]
//   //num=22;

//  // console.log(num);
// }),(err)=> {this.errorMsg =<any>err};


// working


//  Observable.interval(1000).subscribe((x) => {
 this._energyService.getEnergy().subscribe((response) => {
   //alert(2);
      let x=100;
      let y=100;
      console.log(this.numberss = response);
      this.num = response[0].EnergyValue;
      this.title =response[0].EnergyName;
      this.numbers[0] = response[0].EnergyValue;
      this.numbers[1]= x-response[0].EnergyValue;
      this.doughnutChartData= this.numbers;
      this.ref.markForCheck();
      this.emissionfreePercentage = response[1].EnergyValue;
      this.emissionfreeTitle = response[1].EnergyName;
      this.emissionTotal[0] = response[1].EnergyValue;
      this.emissionTotal[1] = y- response[1].EnergyValue;
      this.doughnutChartDataEmission3 = this.emissionTotal;
      console.log(this.numbers[1]);

      // this.ref.detectChanges();
   
     // 
    //this.doughnutChartData3 = this.numbers[0][1]
      //num=22;
    debugger;
     // console.log(num);
    },
    (error) => {
      if(error.status == 404){
this.menulist = true;

this.Wrapper={
  "wrap5":false,
  "wrap6":true
    }
  
        alert(error.status);
      console.log("error 404");
this.loaded();
      
    
      }
      
      
      else{
      
          console.log("error");
      
      }
      
      }
      
      );
  
  
  
  
  
  
//   ),(err)=> { if (err.status== 404){

//       alert("404 error occured");
//     }
//       else{

// alert("400 error occured");

//       }
//       // this.errorMsg =<any>err)
      
//       };
  
  
  
    // });



















// Observable
// .interval(2000)
// .switchMap(() => {
//     return this._energyService.getEnergy()
// }) .catch(err => {
//   // handle errors
//   this.errorMsg = <any>err;
//   // rethrow error
//   return Observable.throw(err);
//   // or just return some correct value
//   // return Observable.of(new Product())

// }).subscribe(response => console.dir(response));





// var chart = new Chart($('#doughnut1'), {
//   type: 'RoundedDoughnut',
 
// });


// Chart.defaults.RoundedDoughnut = Chart.helpers.clone(Chart.defaults.doughnut);
// Chart.controllers.RoundedDoughnut = Chart.controllers.doughnut.extend({
//     draw: function (ease) {
//         var ctx = this.chart.chart.ctx;
        
//         var easingDecimal = ease || 1;
//         Chart.helpers.each(this.getDataset().metaData, function (arc, index) {
//             arc.transition(easingDecimal).draw();

//             var vm = arc._view;
//             var radius = (vm.outerRadius + vm.innerRadius) / 2;
//             var thickness = (vm.outerRadius - vm.innerRadius) / 2;
//             var angle = Math.PI - vm.endAngle - Math.PI / 2;
            
//             ctx.save();
//             ctx.fillStyle = vm.backgroundColor;
//             ctx.translate(vm.x, vm.y);
//             ctx.beginPath();
//             ctx.arc(radius * Math.sin(angle), radius * Math.cos(angle), thickness, 0, 2 * Math.PI);
//             ctx.arc(radius * Math.sin(Math.PI), radius * Math.cos(Math.PI), thickness, 0, 2 * Math.PI);
//             ctx.closePath();
//             ctx.fill();
//             ctx.restore();
//         });
//     },
// });




























    }

   ngAfterViewInit() {
  

    
// 


      

      

      
   





















    Chart.plugins.register({
      beforeDraw: function (chart) {
        if (chart.config.options.elements.center) {
          var ctx = chart.ctx;
          var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
          var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.5);

          //draws arc in the center
          chart.ctx.beginPath();
          chart.ctx.arc(centerX, (centerY + centerY / 4), chart.innerRadius, 0, 2 * Math.PI);
          chart.ctx.fillStyle = 'red';
          chart.ctx.fill();
          chart.ctx.lineWidth = 5;
          chart.ctx.strokeStyle = 'red';
          chart.ctx.stroke();

                 
        }
      }

  //     draw: function (ease) {
  //       var ctx = this.chart.chart.ctx;
  //       var easingDecimal = ease || 1;
  //       Chart.helpers.each(this.getDataset().metaData, function (arc, index) {
  //           arc.transition(easingDecimal).draw();

  //           var vm = arc._view;
  //           var radius = (vm.outerRadius + vm.innerRadius) / 2;
  //           var thickness = (vm.outerRadius - vm.innerRadius) / 2;
  //           var angle = Math.PI - vm.endAngle - Math.PI / 2;
            
  //           ctx.save();
  //           ctx.fillStyle ="red";
  //           ctx.translate(vm.x, vm.y);
  //           ctx.beginPath();
  //           ctx.arc(radius * Math.sin(angle), radius * Math.cos(angle), thickness, 0, 2 * Math.PI);
  //           ctx.arc(radius * Math.sin(Math.PI), radius * Math.cos(Math.PI), thickness, 0, 2 * Math.PI);
  //           ctx.closePath();
  //           ctx.fill();
  //           ctx.restore();
      
      
  //   });
  // },
  });


    // Chart.defaults.global.animation.duration = 12000;







  //   Chart.pluginService.register({
  //     beforeDraw: function (chart) {
  //       if (chart.config.options.elements.center) {
  //         //Get ctx from string
  //         var ctx = chart.chart.ctx;        
  //         //Get options from the center object in options
  //         var centerConfig = chart.config.options.elements.center;
  //         // var fontStyle = centerConfig.fontStyle || 'Arial';  
  //         var fontStyle = 'bold regular  MyriadPro'; 
  //         var txt = centerConfig.text;      
  //         var color = centerConfig.color || '#000';
  //         var sidePadding = centerConfig.sidePadding || 20;
  //         var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
  //         // ctx.font = "22px" + fontStyle;
          
  //         //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
  //         var stringWidth = ctx.measureText(txt).width;
  //         var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;
  
  //         // Find out how much the font can grow in width.
  //         var widthRatio = elementWidth / stringWidth;
  //         var newFontSize = Math.floor(30 * widthRatio);
  //         var elementHeight = (chart.innerRadius * 2);
  
  //         // Pick a new font size so it will not be larger than the height of label.
  //         var fontSizeToUse = Math.min(newFontSize, elementHeight);
  
  //         //Set font settings to draw it correctly.
  //         ctx.textAlign = 'center';
  //         ctx.textBaseline = 'middle';
  //         var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //         var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
  //        // ctx.font =  fontSizeToUse+"px" + fontStyle;
  //         //ctx.font ="1 0px italic Arial";
  //        // console.log(ctx.font);
  //        ctx.fillStyle = color;
    
  //        var array = txt.split("<br>");      
  //        for (var i = 0; i < array.length; i++) {
  //              // console.log(array);    
  //         if(i===0)
  //         {
  //           if(centerX<376)
  //           {  
  //             var centerXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //             var centerYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.3);
  //             ctx.font ="20pt  MyriadPro";
  //             ctx.fillText(array[0],centerXX,centerYY);                  
  //             centerY += 23;          
  //           }       
  //          else
  //          {
  //          var centerXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //          var centerYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.3);
  //          ctx.font ="bold  32pt  MyriadPro";
  //          ctx.fillText(array[0],centerXX,centerYY);
  //          centerYY += 53;           
  //          }
  //         }      
  //         else if(i!=0) {
  //           if(centerX<376 && centerX>250)
  //           {      
  //                 //  alert("x");
  //                 // console.log(centerX);
  //                   // var centerXXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //                   // var centerYYY = ((chart.chartArea.top + chart.chartArea.bottom) / 1.7); 
  //             ctx.font = "bold 10pt  MyriadPro"; 
  //             ctx.fillText(array[i],centerX,centerY);         
  //             centerY += 20;          
  //           }
  //           else if(centerX<250)
  //           {
  //             var centerXXX = ((chart.chartArea.left + chart.chartArea.right) / 2);
  //             var centerYYY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
  //             ctx.font ="bold 8pt MyriadPro";
  //             ctx.fillText(array[i],centerX,centerY-20);
  //             centerY+= 10;                      
  //           }             
  //           else {         
  //             ctx.font = "bold normal 17pt  MyriadPro",
  //             ctx.fillText(array[i],centerX,centerY);
  //              centerY += 50;
  //              }
  //           }
  //  }

  //       }
  //     }
  //   });






  let ctxx= this.mycanvas.nativeElement.getContext("2d");
  // ctxx.defaults.animation.duration = 1000;
  // myChart = new Chart(ctxx, {
  //  type: 'doughnut',
  //  options: {     "cutoutPercentage": 90,
  //   animation: {
  //        duration: 100
  //    },
  //    data: {
  //      labels: ["Wind", "Other"],     
  //  }
  //  }
  // });










 

  } // end of ngAfterInit


  loaded(){
    
      Chart.plugins.register({
        beforeDraw: function (chart) {
          if (chart.config.options.elements.center) {
            var ctx = chart.ctx;
            var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
            var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2.5);
    
            //draws arc in the center
            chart.ctx.beginPath();
            chart.ctx.arc(centerX, (centerY + centerY / 4), chart.innerRadius, 0, 2 * Math.PI);
            chart.ctx.fillStyle = 'black';
            chart.ctx.fill();
            chart.ctx.lineWidth = 5;
            chart.ctx.strokeStyle = 'black';
            chart.ctx.stroke();
    
                   
          }
        }
    })
  }
// widget 2
public doughnutChartLabels:string[] = ['Wind Energy'];
public doughnutChartData:number[] = [];
public doughnutChartType:string = 'doughnut';
private doughnutChartColors1: any[] = [
   { 
    backgroundColor: ["rgba(255, 177, 62, 0.8)", "transparent"],
   // backgroundColor: ["rgba(255, 177, 61, 0.63)", "rgba(255,255,255,.3)"],
    borderColor: 'white',
    borderWidth: [2.5]
   }  
   
];

private doughnutChartOptions: any = {
 cutoutPercentage:55,
//  rotation: (90*Math.PI) - (2/90 * Math.PI),
 rotation: (-0.5 * Math.PI) - (Math.PI),
 responsive: false,
 layout: {
  padding: {
      left: 0,
      right: 2,
      top: 10,
      bottom: 5
  }
 
},
animation:{
  // animateRotate: true,
  // animateScale: true,
  // animationDuration: 9000,
  // rotation:9000,

  segmentShowStroke : true,
  segmentStrokeColor : "#fff",
  segmentStrokeWidth : 2,
  percentageInnerCutout : 50,
  animationSteps : 100,
  animationEasing : "easeOutBounce",
  animateRotate : true,
  animateScale : false,
  responsive: true,
  maintainAspectRatio: true,
  showScale: true,
  duration:3000
},

  title: {
      display: false
  },
  legend: {
    display: false
},  




  elements: {
    center: {
     // text: this.errornumber + "%" +"Energy produced by the Wind", 
      text: this.errornumber +"% <br>Energy produced <br> by Wind Today" ,
      //fontColor: '#fff',
      //fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
     
      fontFamily:"'Arial'",
      //fontSize: ,
      fontStyle: 'Bold Italic'
    }
  }
};

// events
public chartClicked1(e:any):void {
  // console.log(e);
}
public chartHovered1(e:any):void {
  // console.log(e);
}









//widget 2
public doughnutChartLabels3:string[] = ['', ''];
public doughnutChartDataEmission3:number[] = [];
public doughnutChartEmission3: any[] = [
  { 
    // backgroundColor: ["rgba(255,255,255,.9)", "rgba(255,255,255,.3)"],
    //borderColor: 'black'
    //backgroundColor: ["rgba(255,255,255,.7)", "rgba(255,255,255)"],
    // backgroundColor: ["rgba(255,255,255,.7)", "rgba(3, 1, 4, 0)"],
    backgroundColor: ["rgba(255, 128, 0,0.7)", "rgba(255, 255, 255,0.15)"]
   }  
   
];

public doughnutChartData3:number[] = [350, 450, 100];
public doughnutChartType3:string = 'doughnut';

  public chartClicked3(e:any):void {
    console.log(e);
  }
 
  public chartHovered3(e:any):void {
    console.log(e);
  }





  public doughnutChartOptions3: any = {
    cutoutPercentage:55,
   //  rotation: (90*Math.PI) - (2/90 * Math.PI),
  //  rotation: (-0.5 * Math.PI) - (Math.PI),
    responsive: false,
    layout: {
     padding: {
         left: 0,
         right: 2,
         top: 10,
         bottom: 5
     }
    
   },
    animation: {
      // animationSteps : 10000,
      // animateRotate: true,
      // animateScale: true,
      // animationDuration: 111,
      // rotation:7000,
     duration:28000
    }, 
     title: {
         display: false
     },
     legend: {
       display: false
   },  
   
   
   
   
     elements: {
       center: {
        // text: this.errornumber + "%" +"Energy produced by the Wind", 
         text: this.errornumber +"% <br>Energy produced <br> by Wind Today" ,
         //fontColor: '#fff',
         //fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
        
         fontFamily:"'Arial'",
         //fontSize: ,
         fontStyle: 'Bold Italic'
       }
     }
   };





   } // end of component



